package com.example.android.BluetoothChat;

public interface OnRockerListener {
	public void onRocker(int which);
	public void onRocker(MySurfaceView mySurfaceView,int which);
}
