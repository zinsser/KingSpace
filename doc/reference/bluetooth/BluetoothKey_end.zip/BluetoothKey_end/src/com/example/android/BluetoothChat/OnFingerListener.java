package com.example.android.BluetoothChat;

public interface OnFingerListener {
	int inter = 0;
	public void onClick(myView view);
	public void onClick(myView view,int which);
}
