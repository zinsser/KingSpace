package com.gtug.training;

import com.gtug.training.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class UIThreadExample extends Activity {

    private static final int MSG_PROGRESS = 0x101;
    private static final int MSG_DONE = 0x102;
    
    private static final int REQUEST = 1;
    
    private String[] mImageUrls = {
        "http://lh4.ggpht.com/_fMQc2x4ZPx4/SqVDGRnl_qI/AAAAAAAACd0/XRkVE1EAjaE/s576/_MG_1291.jpg",
        "http://lh6.ggpht.com/_fMQc2x4ZPx4/SqVC-XzvCaI/AAAAAAAACdc/AITXk7lmPZc/s576/_MG_1226.jpg",
        "http://lh3.ggpht.com/_fMQc2x4ZPx4/SqVC5M9lXxI/AAAAAAAACdM/5bzaQYY8Ios/s576/_MG_0635.JPG"
    };

    private Button mButton1;
    private Button mButton2;
    private Button mButton3;
    private Button mButton4;
    private ImageView mImageView1;
    private ImageView mImageView2;
    private ProgressBar mProgressBar;
    
    private DownloadTask mDownloadTask;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mButton1 = (Button)findViewById(R.id.button1);
        mButton2 = (Button)findViewById(R.id.button2);
        mButton3 = (Button)findViewById(R.id.button3);
        mButton4 = (Button)findViewById(R.id.button4);
        mImageView1 = (ImageView)findViewById(R.id.image1);
        mImageView2 = (ImageView)findViewById(R.id.image2);
        mProgressBar = (ProgressBar)findViewById(R.id.progress);
        mProgressBar.setVisibility(View.INVISIBLE);
        mButton1.setOnClickListener(mBadClickListener);
        mButton2.setOnClickListener(mHandlerClickListener);
        mButton3.setOnClickListener(mRunOnUIThreadClickListener);
        mButton4.setOnClickListener(mAsyncTaskClickListener);

//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException e) {
//        }
//        Intent intent = new Intent(getApplicationContext(), NewActivity.class);
//        startActivityForResult(intent, REQUEST);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mDownloadTask != null) {
            mDownloadTask.cancel(true);
        }
    }

    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == REQUEST) {
            // do stuff
        } else {
            super.onActivityResult(requestCode, resultCode, data);            
        }
    }


    // Bad usage of UI thread
    private OnClickListener mBadClickListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            mProgressBar.setProgress(0);
            mProgressBar.setVisibility(View.VISIBLE);
            mProgressBar.setIndeterminate(false);
            mImageView1.setImageBitmap(null);
            mImageView2.setImageBitmap(null);            

            int len = mImageUrls.length;
            ArrayList<Bitmap> bmps = new ArrayList<Bitmap>();
            for (int i = 0; i < len; i++) {
                bmps.add(downloadImage(mImageUrls[i]));
                int progress = (i + 1) * 100 / len;
                mProgressBar.setProgress(progress);
            }

            mProgressBar.setVisibility(View.INVISIBLE);
            if (bmps.size() >= 2) {
                mImageView1.setImageBitmap(bmps.get(0));
                mImageView2.setImageBitmap(bmps.get(1));
            }
        }
    };

    // Dealing with UI thread using Handler
    private Handler mHandler = new Handler() {
        @SuppressWarnings("unchecked")
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_PROGRESS:
                    mProgressBar.setProgress(msg.arg1);
                    break;
                case MSG_DONE:
                    ArrayList<Bitmap> bmps = (ArrayList<Bitmap>)msg.obj;
                    if (bmps != null) {
                        mProgressBar.setVisibility(View.INVISIBLE);
                        if (bmps.size() >= 2) {
                            mImageView1.setImageBitmap(bmps.get(0));
                            mImageView2.setImageBitmap(bmps.get(1));
                        }
                    }
                    break;
                default:
                    super.handleMessage(msg);                    
            }
        }
        
    };

    private OnClickListener mHandlerClickListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            mProgressBar.setProgress(0);
            mProgressBar.setVisibility(View.VISIBLE);
            mProgressBar.setIndeterminate(false);
            mImageView1.setImageBitmap(null);
            mImageView2.setImageBitmap(null);

            new Thread(new Runnable() {
                @Override
                public void run() {
                    Message msg = null;
                    int len = mImageUrls.length;
                    final ArrayList<Bitmap> bmps = new ArrayList<Bitmap>();
                    for (int i = 0; i < len; i++) {
                        bmps.add(downloadImage(mImageUrls[i]));
                        int progress = (i + 1) * 100 / len;

                        msg = mHandler.obtainMessage(MSG_PROGRESS, progress, 0);
                        mHandler.sendMessage(msg);
                    }

                    msg = mHandler.obtainMessage(MSG_DONE, bmps);
                    mHandler.sendMessage(msg);
                }
            }).start();

        }
    };

    // Dealing with UI thread using runOnUIThread and post
    private OnClickListener mRunOnUIThreadClickListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            mProgressBar.setProgress(0);
            mProgressBar.setVisibility(View.VISIBLE);
            mProgressBar.setIndeterminate(false);
            mImageView1.setImageBitmap(null);
            mImageView2.setImageBitmap(null);            

            new Thread(new Runnable() {
                @Override
                public void run() {
                    int len = mImageUrls.length;
                    final ArrayList<Bitmap> bmps = new ArrayList<Bitmap>();
                    for (int i = 0; i < len; i++) {
                        bmps.add(downloadImage(mImageUrls[i]));
                        final int progress = (i + 1) * 100 / len;
                        mProgressBar.post(new Runnable() {
                            @Override
                            public void run() {
                                mProgressBar.setProgress(progress);
                            }
                        });
                    }
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mProgressBar.setVisibility(View.INVISIBLE);
                            if (bmps.size() >= 2) {
                                mImageView1.setImageBitmap(bmps.get(0));
                                mImageView2.setImageBitmap(bmps.get(1));
                            }
                        }
                    });
                    
                }
            }).start();
        }
    };

    // UI thread advanced - AsyncTask 
    private OnClickListener mAsyncTaskClickListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            if (mDownloadTask != null) {
                mDownloadTask.cancel(true);
            }
            try {
                mDownloadTask = new DownloadTask();
                mDownloadTask.execute(new URL(mImageUrls[0]), new URL(mImageUrls[1]), new URL(mImageUrls[2]));
            } catch (MalformedURLException e) {
            }

        }
    };

    private class DownloadTask extends AsyncTask<URL, Integer, ArrayList<Bitmap>> {

        @Override
        protected ArrayList<Bitmap> doInBackground(URL... params) {
            ArrayList<Bitmap> results = new ArrayList<Bitmap>();
            int total = params.length;
            for (int i = 0; i < total; i++) {
                results.add(downloadImage(params[i]));
                int progress = (i + 1) * 100 / total;
                publishProgress(progress);
            }
            return results;
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
            mProgressBar.setVisibility(View.INVISIBLE);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            mProgressBar.setProgress(values[0]);
        }

        @Override
        protected void onPreExecute() {
            mProgressBar.setProgress(0);
            mProgressBar.setVisibility(View.VISIBLE);
            mProgressBar.setIndeterminate(false);
            mImageView1.setImageBitmap(null);
            mImageView2.setImageBitmap(null);        
        }

        @Override
        protected void onPostExecute(ArrayList<Bitmap> result) {
            mProgressBar.setVisibility(View.INVISIBLE);
            if (result.size() >= 2) {
                mImageView1.setImageBitmap(result.get(0));
                mImageView2.setImageBitmap(result.get(1));
            }
        }
    }

    
    // Downloading
    private Bitmap downloadImage(String url) {
        URL realUrl = null;
        try {
            realUrl = new URL(url);
        } catch (MalformedURLException e) {
        }
        return downloadImage(realUrl);
    }

    private Bitmap downloadImage(URL url) {
        Bitmap bmp = null;
        HttpURLConnection connection = null;
        InputStream is = null;
        if (url != null) {
            try {
                connection = (HttpURLConnection)url.openConnection();
                connection.setRequestMethod("GET");
                connection.addRequestProperty("Accept","image/jpeg, */*");
                connection.connect();
                is = connection.getInputStream();
                bmp = BitmapFactory.decodeStream(is);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                    }
                }
                if (connection != null) {
                    connection.disconnect();                
                }
            }
        }
        return bmp;
    }
}