/******************************************************************************
 *
 *       Copyright Scartel Starlab, 2009
 *
 *       The copyright notice above does not evidence any
 *       actual or intended publication of such source code.
 *       The code contains Scartel Starlab Confidential Proprietary Information.
 *
 *******************************************************************************/
package com.gtug.training;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author AGolubev
 *
 */
public class MyParcelable implements Parcelable {
    int mData;

    public static final Parcelable.Creator<MyParcelable> CREATOR = new Parcelable.Creator<MyParcelable>() {
        public MyParcelable createFromParcel(Parcel in) {
            return new MyParcelable(in);
        }

        public MyParcelable[] newArray(int size) {
            return new MyParcelable[size];
        }
    };
    
    private MyParcelable(Parcel in) {
        mData = in.readInt();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(mData);
    }
}
