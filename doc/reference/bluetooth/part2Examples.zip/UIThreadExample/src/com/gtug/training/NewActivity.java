/******************************************************************************
 *
 *       Copyright Scartel Starlab, 2009
 *
 *       The copyright notice above does not evidence any
 *       actual or intended publication of such source code.
 *       The code contains Scartel Starlab Confidential Proprietary Information.
 *
 *******************************************************************************/
package com.gtug.training;

import com.gtug.training.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**
 * @author AGolubev
 *
 */
public class NewActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newone);
        Button but = (Button)findViewById(R.id.Button01);
        but.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_OK);
                finish();
            }
        });
    }

}
