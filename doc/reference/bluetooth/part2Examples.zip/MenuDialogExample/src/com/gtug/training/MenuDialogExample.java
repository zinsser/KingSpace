
package com.gtug.training;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.AdapterView.AdapterContextMenuInfo;

public class MenuDialogExample extends ListActivity {

    private static final int MENU_ITEM_1 = 0;
    private static final int MENU_ITEM_2 = 1;
    private static final int MENU_ITEM_3 = 2;

    private static final String MENU_NAME_1 = "First - ";
    private static final String MENU_NAME_2 = "Another - ";

    private static final int DIALOG_YN_1 = 0;
    private static final int DIALOG_DELETE = 1;

    private String[] mListItems = {
            "First", "Second", "Third", "Fourth"
    };

    private int mCounter1;
    private int mCounter2;
    private int mSelectedPosition;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            System.out.println("onCreate: savedInstanceState int = " + savedInstanceState.getInt("int", 0));            
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        for (String next : mListItems) {
            adapter.add(next);
        }
        setListAdapter(adapter);
        // setContentView(R.layout.main);
    }

    @Override
    public void onResume() {
        System.out.println("onResume");
        super.onResume();
        registerForContextMenu(getListView());
    }

    @Override
    public void onPause() {
        System.out.println("onPause");
        super.onPause();
        unregisterForContextMenu(getListView());
    }

    @Override
    public void onRestart() {
        System.out.println("onRestart");
        super.onRestart();
    }

    @Override
    public void onStart() {
        System.out.println("onStart");
        super.onStart();
    }

    @Override
    public void onStop() {
        System.out.println("onStop");
        super.onStop();
    }

    @Override
    public void onDestroy() {
        System.out.println("onDestroy");
        super.onDestroy();
    }
    
    @Override
    protected void onRestoreInstanceState(Bundle state) {
        System.out.println("onRestoreInstanceState");
        System.out.println("state int = " + state.getInt("int", 0));
        super.onRestoreInstanceState(state);
    }

    @Override
    public Object onRetainNonConfigurationInstance() {
        System.out.println("onRetainNonConfigurationInstance");
        return super.onRetainNonConfigurationInstance();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        System.out.println("onSaveInstanceState");
        super.onSaveInstanceState(outState);
        outState.putInt("int", 324);
    }

    /* === Options menu === */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_ITEM_1, 0, MENU_NAME_1);
        menu.add(0, MENU_ITEM_2, 0, MENU_NAME_2);
        menu.add(0, MENU_ITEM_3, 0, "Close").setIcon(android.R.drawable.ic_menu_close_clear_cancel).setAlphabeticShortcut('q');;
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item1 = menu.findItem(MENU_ITEM_1);
        MenuItem item2 = menu.findItem(MENU_ITEM_2);
        if (item1 != null && item2 != null) {
            item1.setTitle(MENU_NAME_1 + mCounter1);
            item2.setTitle(MENU_NAME_2 + mCounter2);
        }
        menu.findItem(MENU_ITEM_3).setEnabled(mCounter1 == mCounter2);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case MENU_ITEM_1:
                mCounter1++;
                Toast.makeText(this, "First selected", Toast.LENGTH_SHORT).show();
                return true;
            case MENU_ITEM_2:
                mCounter2++;
                Toast.makeText(this, "Another item selected", Toast.LENGTH_SHORT).show();
                return true;
            case MENU_ITEM_3:
                showDialog(DIALOG_YN_1);
                return true;
        }
        return false;
    }

    @Override
    public void onOptionsMenuClosed(Menu menu) {
        super.onOptionsMenuClosed(menu);
    }

    /* === Context menu === */
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, MENU_ITEM_1, 0, "Edit");
        menu.add(0, MENU_ITEM_2, 0, "Delete");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterContextMenuInfo info = (AdapterContextMenuInfo)item.getMenuInfo();
        switch (item.getItemId()) {
            case MENU_ITEM_1:
                Toast.makeText(this, "Edit - " + getListAdapter().getItem(info.position), Toast.LENGTH_LONG).show();
                return true;
            case MENU_ITEM_2:
                mSelectedPosition = info.position;
                showDialog(DIALOG_DELETE);
                return true;
            default:
                return super.onContextItemSelected(item);
        }

    }

    @Override
    public void onContextMenuClosed(Menu menu) {
        super.onContextMenuClosed(menu);
    }

    /* === Panel Menu === */
    @Override
    public View onCreatePanelView(int featureId) {
        return super.onCreatePanelView(featureId);
    }
    
    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        System.out.println("onCreatePanelMenu, featureId = " + featureId);
        return super.onCreatePanelMenu(featureId, menu);
    }

    @Override
    public boolean onPreparePanel(int featureId, View view, Menu menu) {
        return super.onPreparePanel(featureId, view, menu);
    }

    @Override
    public boolean onMenuItemSelected(int featureId, MenuItem item) {
        return super.onMenuItemSelected(featureId, item);
    }

    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {
        return super.onMenuOpened(featureId, menu);
    }

    @Override
    public void onPanelClosed(int featureId, Menu menu) {
        super.onPanelClosed(featureId, menu);
    }

    /* === Dialog === */
    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_YN_1:
                return new AlertDialog.Builder(this).setMessage("Are you sure?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).create();
            case DIALOG_DELETE:
                return new AlertDialog.Builder(this).setTitle("Delete?").setMessage("").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Delete: " + getListAdapter().getItem(mSelectedPosition), Toast.LENGTH_LONG).show();
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).create();

            default:
                return super.onCreateDialog(id);
        }
    }

    @Override
    protected void onPrepareDialog(int id, Dialog dialog) {
        switch (id) {
            case DIALOG_DELETE:
                ((AlertDialog)dialog).setMessage(getListAdapter().getItem(mSelectedPosition).toString());
                break;
        }
        super.onPrepareDialog(id, dialog);
    }

}
